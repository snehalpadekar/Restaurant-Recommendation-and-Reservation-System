-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: r3_db_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dish_categories`
--

DROP TABLE IF EXISTS `dish_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dish_categories` (
  `category_id` int NOT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dish_categories`
--

LOCK TABLES `dish_categories` WRITE;
/*!40000 ALTER TABLE `dish_categories` DISABLE KEYS */;
INSERT INTO `dish_categories` VALUES (12001,'Burgers'),(12002,'Hot Dogs'),(12003,'Sandwiches'),(12004,'Fries'),(12005,'All Sandwiches'),(12006,'Signature Wraps'),(12007,'Breakfast'),(12008,'Subway Fresh Fit'),(12009,'Chopped Salads'),(12010,'Subway Sliders'),(12011,'Sides'),(12012,'Flatizzas'),(12013,'Chicken & Sandwiches'),(12014,'Nuggets'),(12015,'Salads'),(12016,'Snacks & Sides'),(12017,'Happy Meals'),(12018,'Oatmeal'),(12019,'Limited Time Offers'),(12020,'Bakery'),(12021,'All-Day Breakfast'),(12022,'Lunch & Anytime Snacks'),(12023,'Hot \'n Juicy Cheeseburgers'),(12024,'Tender Juicy Chicken'),(12025,'Fresh Salads'),(12026,'Right Price Right Size Menu'),(12027,'Hot Stuffed Baked Potatoes'),(12028,'4 for $4 Meal'),(12029,'Kid\'s Meal'),(12030,'Chicken Sandwiches'),(12031,'Chicken Combos'),(12032,'Tender Combos'),(12033,'Seafood'),(12034,'Chicken Family Meals'),(12035,'Signature Sides'),(12036,'Kids Meal'),(12037,'Desserts'),(12038,'Family Feasts'),(12039,'Chicken'),(12040,'Flat-Top Dogs'),(12041,'Crinkle Cut Fries'),(12042,'Frozen Custard'),(12043,'Woof - Food for Pets'),(12044,'Cheese Pizzas'),(12045,'Specialty Pizzas'),(12046,'Feast Pizzas'),(12047,'Pasta'),(12048,'Breads'),(12049,'Chips'),(12050,'Sauces'),(12051,'Combos'),(12052,'Nashville Hot Chicken'),(12053,'Nashville Hot Tenders'),(12054,'Tenders, Popcorn Nuggets, and Wings'),(12055,'Family Meals'),(12056,'Homestyle Sides'),(12057,'$20 Family Fill Up'),(12058,'$5 Family Fill Up'),(12059,'Big Box Meals'),(12060,'Classics'),(12061,'Promotions'),(12062,'Signature Flavors'),(12063,'Craft 2 Menu'),(12064,'Burritos'),(12065,'Taco Salads'),(12066,'Grilled Quesadilla'),(12067,'Tacos'),(12068,'Qdoba Kids Meal'),(12069,'Chips & Dips'),(12070,'Dunkin Donuts Combos'),(12071,'Anytime Breakfast'),(12072,'Bakery Favorites'),(12073,'Pizzas'),(12074,'Dessert'),(12075,'Signature Panini'),(12076,'Premium Signature Sandwiches'),(12077,'Signature Sandwiches'),(12078,'Café Sandwiches'),(12079,'Broth Bowls'),(12080,'Premium Signature Pastas'),(12081,'Signature Pastas'),(12082,'Flatbreads'),(12083,'Signature Salads'),(12084,'Individual Soups'),(12085,'Group -Soups'),(12086,'Panera-Kid\'s'),(12087,'Bagels'),(12088,'Spreads'),(12089,'Parfaits, Fruit & Oatmeal'),(12090,'Pasteries & Sweets'),(12091,'Brownies & Cookies'),(12092,'Cupcakes, Muffin, Muffies & Scones'),(12093,'Appetizers'),(12094,'Soups'),(12095,'Ultimate Lunch Combo'),(12096,'Scratch Burgers'),(12097,'Favorites'),(12098,'Steaks'),(12099,'House-Smoked Baby Back Ribs'),(12100,'Combinations'),(12101,'Lighter Side'),(12102,'Fish'),(12103,'Made-From-Scratch Sides'),(12104,'Kids'),(12105,'Main Menu'),(12106,'Value Menu'),(12107,'Salads & More'),(12108,'Kids Menu');
/*!40000 ALTER TABLE `dish_categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-14 20:41:16
