-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: r3_db_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `restaurant_reservation`
--

DROP TABLE IF EXISTS `restaurant_reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant_reservation` (
  `reservation_id` int NOT NULL,
  `no_of_people` int DEFAULT NULL,
  `reservation_time` time DEFAULT NULL,
  `reservation_date` date DEFAULT NULL,
  `restaurant_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`reservation_id`),
  UNIQUE KEY `index_restaurant_reservation` (`reservation_id`),
  KEY `restaurant_id` (`restaurant_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `restaurant_reservation_ibfk_1` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurant` (`restaurant_id`),
  CONSTRAINT `restaurant_reservation_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_reservation`
--

LOCK TABLES `restaurant_reservation` WRITE;
/*!40000 ALTER TABLE `restaurant_reservation` DISABLE KEYS */;
INSERT INTO `restaurant_reservation` VALUES (9003,3,'20:23:45','2022-01-11',1006,2041),(9004,4,'21:13:25','2022-05-12',1005,2025),(9005,6,'22:23:37','2022-05-13',1006,2071),(9006,5,'23:23:12','2022-05-14',1007,2006),(9007,2,'18:23:25','2022-05-15',1001,2016),(9009,5,'19:22:27','2022-05-17',1005,2007),(9010,6,'20:25:45','2022-12-04',1002,2081),(9011,3,'21:23:32','2022-12-05',1008,2027),(9012,7,'22:23:45','2022-12-06',1001,2090),(9013,2,'23:34:23','2022-12-07',1015,2061),(9014,4,'18:23:34','2022-12-08',1008,2068),(9015,3,'19:23:46','2022-12-09',1010,2085),(9016,5,'20:22:45','2022-12-10',1009,2083),(9017,3,'21:23:12','2022-12-11',1003,2008),(9018,6,'22:23:45','2022-05-16',1007,2076),(9019,4,'23:29:45','2021-02-14',1002,2073),(9020,5,'11:23:12','2022-02-14',1007,2018),(9021,7,'15:23:45','2022-05-17',1004,2074),(9022,3,'16:23:14','2022-12-04',1001,2003),(9023,4,'17:23:45','2022-08-15',1014,2087),(9024,5,'18:23:25','2022-08-15',1008,2048),(9025,2,'19:23:45','2021-09-08',1004,2015),(9026,3,'20:23:52','2022-12-07',1013,2010),(9027,5,'21:14:45','2022-12-09',1009,2072),(9028,4,'22:23:54','2022-09-12',1010,2043),(9029,5,'23:23:47','2022-05-12',1006,2083),(9030,5,'21:13:25','2022-05-14',1006,2009),(9031,4,'21:15:25','2022-06-14',1006,2009),(9032,4,'21:15:25','2022-01-14',1002,2009),(9033,4,'21:00:00','2022-12-30',1010,2009);
/*!40000 ALTER TABLE `restaurant_reservation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-14 20:41:15
