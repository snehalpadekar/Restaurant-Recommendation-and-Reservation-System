-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: r3_db_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant` (
  `restaurant_id` int NOT NULL,
  `restaurant_name` varchar(100) DEFAULT NULL,
  `restaurant_rating` float DEFAULT NULL,
  `restaurant_contact_no` varchar(100) DEFAULT NULL,
  `opening_hrs` time DEFAULT NULL,
  `closing_hrs` time DEFAULT NULL,
  `budget_for_2` int DEFAULT NULL,
  `restaurant_address` varchar(100) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `zipcode` int DEFAULT NULL,
  `no_of_tables` int DEFAULT NULL,
  PRIMARY KEY (`restaurant_id`),
  KEY `index_restaurant_id` (`restaurant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant`
--

LOCK TABLES `restaurant` WRITE;
/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
INSERT INTO `restaurant` VALUES (1001,'Five Guys',4.3,'(617) 936-3657','11:00:00','22:00:00',41,'263 Huntington Ave, Boston, ','Boston','MA',2115,20),(1002,'Subway',3.7,'(617) 373-4613','00:00:00','00:00:00',45,'Ryder hall, Leon St, Boston, ','Boston','MA',2115,13),(1003,'Mcdonalds',3.6,'(617) 778-5228','06:00:00','00:00:00',38,'540 Commonwealth Ave, Boston, ','Boston','MA',2215,10),(1004,'Starbucks',3.7,'(617) 373-2530','07:00:00','21:00:00',26,'360 Huntington Ave, Boston, ','Boston','MA',2115,15),(1005,'Wendys',3.9,'(617) 236-1550','08:00:00','23:30:00',24,'157-A Massachusetts Ave, Boston, ','Boston','MA',2127,25),(1006,'Popeyes',3.9,'(617) 373-4950','00:00:00','19:00:00',24,'Northeastern University, 360 Huntington Ave, Boston, ','Boston','MA',2115,15),(1007,'Shake shack',4.3,'(617) 933-5050','11:00:00','22:00:00',43,'234-236 Newbury St, Boston, ','Boston','MA',2116,20),(1008,'Dominos',2.6,'(617) 541-3525','10:00:00','03:00:00',42,'1400 Tremont St Roxbury Crossing Station - Space D, Crossing, ','Boston','MA',2120,15),(1009,'KFC',3.6,'(617) 282-2068','10:00:00','23:00:00',22,'695 Columbia Rd, Dorchester, ','Boston','MA',2125,11),(1010,'Qdoba',4.1,'(617) 450-0910','10:30:00','23:00:00',33,'393 Huntington Ave Ste 101, Boston, ','Boston','MA',2115,8),(1011,'Dunkin Donuts',4.2,'(617) 373-8414','08:00:00','14:00:00',17,'Northeastern - Shillman Hall, 115 Forsyth St, Boston, ','Boston','MA',2115,15),(1012,'Blaze Pizza',4.5,'(617) 297-9585','11:00:00','22:00:00',11,'1282 Boylston St, Boston, ','Boston','MA',2215,12),(1013,'Panera Bread',3.9,'(617) 425-8565','06:00:00','22:00:00',49,'289 Huntington Ave, Boston, ','Boston','MA',2115,10),(1014,'Cheddars',4.6,'(617) 375-6333','10:00:00','20:00:00',41,'1638 Washington St, Boston, ','Boston','MA',2118,20),(1015,'Burger King',3.8,'(617) 556-8299','07:00:00','22:00:00',37,'128 Tremont St, Boston, ','Boston','MA',2108,25);
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-14 20:41:16
