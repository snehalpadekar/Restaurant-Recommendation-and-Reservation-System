-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: r3_db_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL,
  `user_first_name` varchar(100) DEFAULT NULL,
  `user_last_name` varchar(100) DEFAULT NULL,
  `user_address` varchar(500) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `county` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `zipcode` int DEFAULT NULL,
  `user_contact_no` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `index_name` (`user_first_name`,`user_last_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2001,'James','Butt','6649 N Blue Gum St','New Orleans','Orleans','LA',70116,'504-845-1427'),(2002,'Josephine','Darakjy','4 B Blue Ridge Blvd','Brighton','Livingston','MI',48116,'810-374-9840'),(2003,'Art','Venere','8 W Cerritos Ave #54','Bridgeport','Gloucester','NJ',8014,'856-264-4130'),(2004,'Lenna','Paprocki','639 Main St','Anchorage','Anchorage','AK',99501,'907-921-2010'),(2005,'Donette','Foller','34 Center St','Hamilton','Butler','OH',45011,'513-549-4561'),(2006,'Simona','Morasca','3 Mcauley Dr','Ashland','Ashland','OH',44805,'419-800-6759'),(2007,'Mitsue','Tollner','7 Eads St','Chicago','Cook','IL',60632,'773-924-8565'),(2008,'Leota','Dilliard','7 W Jackson Blvd','San Jose','Santa Clara','CA',95111,'408-813-1105'),(2009,'Sage','Wieser','5 Boston Ave #88','Sioux Falls','Minnehaha','SD',57105,'605-794-4895'),(2010,'Kris','Marrier','228 Runamuck Pl #2808','Baltimore','Baltimore City','MD',21224,'410-804-4694'),(2011,'Minna','Amigon','2371 Jerrold Ave','Kulpsville','Montgomery','PA',19443,'215-422-8694'),(2012,'Abel','Maclead','37275 St  Rt 17m M','Middle Island','Suffolk','NY',11953,'631-677-3675'),(2013,'Kiley','Caldarera','25 E 75th St #69','Los Angeles','Los Angeles','CA',90034,'310-254-3084'),(2014,'Graciela','Ruta','98 Connecticut Ave Nw','Chagrin Falls','Geauga','OH',44023,'440-579-7763'),(2015,'Cammy','Albares','56 E Morehead St','Laredo','Webb','TX',78045,'956-841-7216'),(2016,'Mattie','Poquette','73 State Road 434 E','Phoenix','Maricopa','AZ',85013,'602-953-6360'),(2017,'Meaghan','Garufi','69734 E Carrillo St','Mc Minnville','Warren','TN',37110,'931-235-7959'),(2018,'Gladys','Rim','322 New Horizon Blvd','Milwaukee','Milwaukee','WI',53207,'414-377-2880'),(2019,'Yuki','Whobrey','1 State Route 27','Taylor','Wayne','MI',48180,'313-341-4470'),(2020,'Fletcher','Flosi','394 Manchester Blvd','Rockford','Winnebago','IL',61109,'815-426-5657'),(2021,'Bette','Nicka','6 S 33rd St','Aston','Delaware','PA',19014,'610-492-4643'),(2022,'Veronika','Inouye','6 Greenleaf Ave','San Jose','Santa Clara','CA',95111,'408-813-4592'),(2023,'Willard','Kolmetz','618 W Yakima Ave','Irving','Dallas','TX',75062,'972-896-4882'),(2024,'Maryann','Royster','74 S Westgate St','Albany','Albany','NY',12204,'518-448-8982'),(2025,'Alisha','Slusarski','3273 State St','Middlesex','Middlesex','NJ',8846,'732-635-3453'),(2026,'Allene','Iturbide','1 Central Ave','Stevens Point','Portage','WI',54481,'715-530-9863'),(2027,'Chanel','Caudy','86 Nw 66th St #8673','Shawnee','Johnson','KS',66218,'913-899-1103'),(2028,'Ezekiel','Chui','2 Cedar Ave #84','Easton','Talbot','MD',21601,'410-235-8738'),(2029,'Willow','Kusko','90991 Thorburn Ave','New York','New York','NY',10011,'212-934-5167'),(2030,'Bernardo','Figeroa','386 9th Ave N','Conroe','Montgomery','TX',77301,'936-597-3614'),(2031,'Ammie','Corrio','74874 Atlantic Ave','Columbus','Franklin','OH',43215,'614-648-3265'),(2032,'Francine','Vocelka','366 South Dr','Las Cruces','Dona Ana','NM',88011,'505-335-5293'),(2033,'Ernie','Stenseth','45 E Liberty St','Ridgefield Park','Bergen','NJ',7660,'201-387-9093'),(2034,'Albina','Glick','4 Ralph Ct','Dunellen','Middlesex','NJ',8812,'732-782-6701'),(2035,'Alishia','Sergi','2742 Distribution Way','New York','New York','NY',10025,'212-753-2740'),(2036,'Solange','Shinko','426 Wolf St','Metairie','Jefferson','LA',70002,'504-265-8174'),(2037,'Jose','Stockham','128 Bransten Rd','New York','New York','NY',10011,'212-569-4233'),(2038,'Rozella','Ostrosky','17 Morena Blvd','Camarillo','Ventura','CA',93012,'805-609-1531'),(2039,'Valentine','Gillian','775 W 17th St','San Antonio','Bexar','TX',78204,'210-300-6244'),(2040,'Kati','Rulapaugh','6980 Dorsett Rd','Abilene','Dickinson','KS',67410,'785-219-7724'),(2041,'Youlanda','Schemmer','2881 Lewis Rd','Prineville','Crook','OR',97754,'541-993-2611'),(2042,'Dyan','Oldroyd','7219 Woodfield Rd','Overland Park','Johnson','KS',66204,'913-645-8918'),(2043,'Roxane','Campain','1048 Main St','Fairbanks','Fairbanks North Star','AK',99708,'907-335-6568'),(2044,'Lavera','Perin','678 3rd Ave','Miami','Miami-Dade','FL',33196,'305-995-2078'),(2045,'Erick','Ferencz','20 S Babcock St','Fairbanks','Fairbanks North Star','AK',99712,'907-227-6777'),(2046,'Fatima','Saylors','2 Lighthouse Ave','Hopkins','Hennepin','MN',55343,'952-479-2375'),(2047,'Jina','Briddick','38938 Park Blvd','Boston','Suffolk','MA',2128,'617-997-5771'),(2048,'Kanisha','Waycott','5 Tomahawk Dr','Los Angeles','Los Angeles','CA',90006,'323-315-7314'),(2049,'Emerson','Bowley','762 S Main St','Madison','Dane','WI',53711,'608-658-7940'),(2050,'Blair','Malet','209 Decker Dr','Philadelphia','Philadelphia','PA',19132,'215-794-4519'),(2051,'Brock','Bolognia','4486 W O St #1','New York','New York','NY',10003,'212-617-5063'),(2052,'Lorrie','Nestle','39 S 7th St','Tullahoma','Coffee','TN',37388,'931-303-6041'),(2053,'Sabra','Uyetake','98839 Hawthorne Blvd #6101','Columbia','Richland','SC',29201,'803-681-3678'),(2054,'Marjory','Mastella','71 San Mateo Ave','Wayne','Delaware','PA',19087,'610-379-7125'),(2055,'Karl','Klonowski','76 Brooks St #9','Flemington','Hunterdon','NJ',8822,'908-470-4661'),(2056,'Tonette','Wenner','4545 Courthouse Rd','Westbury','Nassau','NY',11590,'516-333-4861'),(2057,'Amber','Monarrez','14288 Foster Ave #4121','Jenkintown','Montgomery','PA',19046,'215-329-6386'),(2058,'Shenika','Seewald','4 Otis St','Van Nuys','Los Angeles','CA',91405,'818-749-8650'),(2059,'Delmy','Ahle','65895 S 16th St','Providence','Providence','RI',2909,'401-559-8961'),(2060,'Deeanna','Juhas','14302 Pennsylvania Ave','Huntingdon Valley','Montgomery','PA',19006,'215-417-9563'),(2061,'Blondell','Pugh','201 Hawk Ct','Providence','Providence','RI',2904,'401-300-8122'),(2062,'Jamal','Vanausdal','53075 Sw 152nd Ter #615','Monroe Township','Middlesex','NJ',8831,'732-904-2931'),(2063,'Cecily','Hollack','59 N Groesbeck Hwy','Austin','Travis','TX',78731,'512-861-3814'),(2064,'Carmelina','Lindall','2664 Lewis Rd','Littleton','Douglas','CO',80126,'303-874-5160'),(2065,'Maurine','Yglesias','59 Shady Ln #53','Milwaukee','Milwaukee','WI',53214,'414-573-7719'),(2066,'Tawna','Buvens','3305 Nabell Ave #679','New York','New York','NY',10009,'212-462-9157'),(2067,'Penney','Weight','18 Fountain St','Anchorage','Anchorage','AK',99515,'907-873-2882'),(2068,'Elly','Morocco','7 W 32nd St','Erie','Erie','PA',16502,'814-420-3553'),(2069,'Ilene','Eroman','2853 S Central Expy','Glen Burnie','Anne Arundel','MD',21061,'410-937-4543'),(2070,'Vallie','Mondella','74 W College St','Boise','Ada','ID',83707,'208-737-8439'),(2071,'Kallie','Blackwood','701 S Harrison Rd','San Francisco','San Francisco','CA',94104,'415-604-7609'),(2072,'Johnetta','Abdallah','1088 Pinehurst St','Chapel Hill','Orange','NC',27514,'919-715-3791'),(2073,'Bobbye','Rhym','30 W 80th St #1995','San Carlos','San Mateo','CA',94070,'650-811-9032'),(2074,'Micaela','Rhymes','20932 Hedley St','Concord','Contra Costa','CA',94520,'925-522-7798'),(2075,'Tamar','Hoogland','2737 Pistorio Rd #9230','London','Madison','OH',43140,'740-526-5410'),(2076,'Moon','Parlato','74989 Brandon St','Wellsville','Allegany','NY',14895,'585-498-4278'),(2077,'Laurel','Reitler','6 Kains Ave','Baltimore','Baltimore City','MD',21215,'410-957-6903'),(2078,'Delisa','Crupi','47565 W Grand Ave','Newark','Essex','NJ',7105,'973-847-9611'),(2079,'Viva','Toelkes','4284 Dorigo Ln','Chicago','Cook','IL',60647,'773-352-3437'),(2080,'Elza','Lipke','6794 Lake Dr E','Newark','Essex','NJ',7104,'973-796-3667'),(2081,'Devorah','Chickering','31 Douglas Blvd #950','Clovis','Curry','NM',88101,'505-950-1763'),(2082,'Timothy','Mulqueen','44 W 4th St','Staten Island','Richmond','NY',10309,'718-654-7063'),(2083,'Arlette','Honeywell','11279 Loytan St','Jacksonville','Duval','FL',32254,'904-514-9918'),(2084,'Dominque','Dickerson','69 Marquette Ave','Hayward','Alameda','CA',94545,'510-901-7640'),(2085,'Lettie','Isenhower','70 W Main St','Beachwood','Cuyahoga','OH',44122,'216-733-8494'),(2086,'Myra','Munns','461 Prospect Pl #316','Euless','Tarrant','TX',76040,'817-451-3518'),(2087,'Stephaine','Barfield','47154 Whipple Ave Nw','Gardena','Los Angeles','CA',90247,'310-968-1219'),(2088,'Lai','Gato','37 Alabama Ave','Evanston','Cook','IL',60201,'847-957-4614'),(2089,'Stephen','Emigh','3777 E Richmond St #900','Akron','Summit','OH',44302,'330-700-2312'),(2090,'Tyra','Shields','3 Fort Worth Ave','Philadelphia','Philadelphia','PA',19106,'215-228-8264'),(2091,'Tammara','Wardrip','4800 Black Horse Pike','Burlingame','San Mateo','CA',94010,'650-216-5075'),(2092,'Cory','Gibes','83649 W Belmont Ave','San Gabriel','Los Angeles','CA',91776,'626-696-2777'),(2093,'Danica','Bruschke','840 15th Ave','Waco','McLennan','TX',76708,'254-205-1422'),(2094,'Wilda','Giguere','1747 Calle Amanecer #2','Anchorage','Anchorage','AK',99501,'907-914-9482'),(2095,'Elvera','Benimadho','99385 Charity St #840','San Jose','Santa Clara','CA',95110,'408-440-8447'),(2096,'Carma','Vanheusen','68556 Central Hwy','San Leandro','Alameda','CA',94577,'510-452-4835'),(2097,'Malinda','Hochard','55 Riverside Ave','Indianapolis','Marion','IN',46202,'317-472-2412'),(2098,'Natalie','Fern','7140 University Ave','Rock Springs','Sweetwater','WY',82901,'307-279-3793'),(2099,'Lisha','Centini','64 5th Ave #1153','Mc Lean','Fairfax','VA',22102,'703-475-7568');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-14 20:41:13
