-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: r3_db_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `account_id` int NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `account_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (7001,'jbutt@gmail.com','XXXXX',2001),(7002,'josephine_darakjy@darakjy.org','XXXXX',2002),(7003,'art@venere.org','XXXXX',2003),(7004,'lpaprocki@hotmail.com','XXXXX',2004),(7005,'donette.foller@cox.net','XXXXX',2005),(7006,'simona@morasca.com','XXXXX',2006),(7007,'mitsue_tollner@yahoo.com','XXXXX',2007),(7008,'leota@hotmail.com','XXXXX',2008),(7009,'sage_wieser@cox.net','XXXXX',2009),(7010,'kris@gmail.com','XXXXX',2010),(7011,'minna_amigon@yahoo.com','XXXXX',2011),(7012,'amaclead@gmail.com','XXXXX',2012),(7013,'kiley.caldarera@aol.com','XXXXX',2013),(7014,'gruta@cox.net','XXXXX',2014),(7015,'calbares@gmail.com','XXXXX',2015),(7016,'mattie@aol.com','XXXXX',2016),(7017,'meaghan@hotmail.com','XXXXX',2017),(7018,'gladys.rim@rim.org','XXXXX',2018),(7019,'yuki_whobrey@aol.com','XXXXX',2019),(7020,'fletcher.flosi@yahoo.com','XXXXX',2020),(7021,'bette_nicka@cox.net','XXXXX',2021),(7022,'vinouye@aol.com','XXXXX',2022),(7023,'willard@hotmail.com','XXXXX',2023),(7024,'mroyster@royster.com','XXXXX',2024),(7025,'alisha@slusarski.com','XXXXX',2025),(7026,'allene_iturbide@cox.net','XXXXX',2026),(7027,'chanel.caudy@caudy.org','XXXXX',2027),(7028,'ezekiel@chui.com','XXXXX',2028),(7029,'wkusko@yahoo.com','XXXXX',2029),(7030,'bfigeroa@aol.com','XXXXX',2030),(7031,'ammie@corrio.com','XXXXX',2031),(7032,'francine_vocelka@vocelka.com','XXXXX',2032),(7033,'ernie_stenseth@aol.com','XXXXX',2033),(7034,'albina@glick.com','XXXXX',2034),(7035,'asergi@gmail.com','XXXXX',2035),(7036,'solange@shinko.com','XXXXX',2036),(7037,'jose@yahoo.com','XXXXX',2037),(7038,'rozella.ostrosky@ostrosky.com','XXXXX',2038),(7039,'valentine_gillian@gmail.com','XXXXX',2039),(7040,'kati.rulapaugh@hotmail.com','XXXXX',2040),(7041,'youlanda@aol.com','XXXXX',2041),(7042,'doldroyd@aol.com','XXXXX',2042),(7043,'roxane@hotmail.com','XXXXX',2043),(7044,'lperin@perin.org','XXXXX',2044),(7045,'erick.ferencz@aol.com','XXXXX',2045),(7046,'fsaylors@saylors.org','XXXXX',2046),(7047,'jina_briddick@briddick.com','XXXXX',2047),(7048,'kanisha_waycott@yahoo.com','XXXXX',2048),(7049,'emerson.bowley@bowley.org','XXXXX',2049),(7050,'bmalet@yahoo.com','XXXXX',2050),(7051,'bbolognia@yahoo.com','XXXXX',2051),(7052,'lnestle@hotmail.com','XXXXX',2052),(7053,'sabra@uyetake.org','XXXXX',2053),(7054,'mmastella@mastella.com','XXXXX',2054),(7055,'karl_klonowski@yahoo.com','XXXXX',2055),(7056,'twenner@aol.com','XXXXX',2056),(7057,'amber_monarrez@monarrez.org','XXXXX',2057),(7058,'shenika@gmail.com','XXXXX',2058),(7059,'delmy.ahle@hotmail.com','XXXXX',2059),(7060,'deeanna_juhas@gmail.com','XXXXX',2060),(7061,'bpugh@aol.com','XXXXX',2061),(7062,'jamal@vanausdal.org','XXXXX',2062),(7063,'cecily@hollack.org','XXXXX',2063),(7064,'carmelina_lindall@lindall.com','XXXXX',2064),(7065,'maurine_yglesias@yglesias.com','XXXXX',2065),(7066,'tawna@gmail.com','XXXXX',2066),(7067,'penney_weight@aol.com','XXXXX',2067),(7068,'elly_morocco@gmail.com','XXXXX',2068),(7069,'ilene.eroman@hotmail.com','XXXXX',2069),(7070,'vmondella@mondella.com','XXXXX',2070),(7071,'kallie.blackwood@gmail.com','XXXXX',2071),(7072,'johnetta_abdallah@aol.com','XXXXX',2072),(7073,'brhym@rhym.com','XXXXX',2073),(7074,'micaela_rhymes@gmail.com','XXXXX',2074),(7075,'tamar@hotmail.com','XXXXX',2075),(7076,'moon@yahoo.com','XXXXX',2076),(7077,'laurel_reitler@reitler.com','XXXXX',2077),(7078,'delisa.crupi@crupi.com','XXXXX',2078),(7079,'viva.toelkes@gmail.com','XXXXX',2079),(7080,'elza@yahoo.com','XXXXX',2080),(7081,'devorah@hotmail.com','XXXXX',2081),(7082,'timothy_mulqueen@mulqueen.org','XXXXX',2082),(7083,'ahoneywell@honeywell.com','XXXXX',2083),(7084,'dominque.dickerson@dickerson.org','XXXXX',2084),(7085,'lettie_isenhower@yahoo.com','XXXXX',2085),(7086,'mmunns@cox.net','XXXXX',2086),(7087,'stephaine@barfield.com','XXXXX',2087),(7088,'lai.gato@gato.org','XXXXX',2088),(7089,'stephen_emigh@hotmail.com','XXXXX',2089),(7090,'tshields@gmail.com','XXXXX',2090),(7091,'twardrip@cox.net','XXXXX',2091),(7092,'cory.gibes@gmail.com','XXXXX',2092),(7093,'danica_bruschke@gmail.com','XXXXX',2093),(7094,'wilda@cox.net','XXXXX',2094),(7095,'elvera.benimadho@cox.net','XXXXX',2095),(7096,'carma@cox.net','XXXXX',2096),(7097,'malinda.hochard@yahoo.com','XXXXX',2097),(7098,'natalie.fern@hotmail.com','XXXXX',2098),(7099,'lisha@centini.org','XXXXX',2099);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-14 20:41:14
