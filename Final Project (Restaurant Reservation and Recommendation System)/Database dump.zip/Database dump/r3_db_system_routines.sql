-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: r3_db_system
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `rescategory`
--

DROP TABLE IF EXISTS `rescategory`;
/*!50001 DROP VIEW IF EXISTS `rescategory`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `rescategory` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `restaurant_rating`,
 1 AS `opening_hrs`,
 1 AS `closing_hrs`,
 1 AS `budget_for_2`,
 1 AS `restaurant_address`,
 1 AS `zipcode`,
 1 AS `city`,
 1 AS `state`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `cancellation_details`
--

DROP TABLE IF EXISTS `cancellation_details`;
/*!50001 DROP VIEW IF EXISTS `cancellation_details`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `cancellation_details` AS SELECT 
 1 AS `restaurant_id`,
 1 AS `restaurant_name`,
 1 AS `count(c.cancellation_id)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `prices_popeyes`
--

DROP TABLE IF EXISTS `prices_popeyes`;
/*!50001 DROP VIEW IF EXISTS `prices_popeyes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `prices_popeyes` AS SELECT 
 1 AS `dish_id`,
 1 AS `dish_name`,
 1 AS `dish_price`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `fast_food_resto`
--

DROP TABLE IF EXISTS `fast_food_resto`;
/*!50001 DROP VIEW IF EXISTS `fast_food_resto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `fast_food_resto` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `restaurant_type`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `coffee_and_fries`
--

DROP TABLE IF EXISTS `coffee_and_fries`;
/*!50001 DROP VIEW IF EXISTS `coffee_and_fries`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `coffee_and_fries` AS SELECT 
 1 AS `restaurant_id`,
 1 AS `restaurant_name`,
 1 AS `restaurant_rating`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `drinktable`
--

DROP TABLE IF EXISTS `drinktable`;
/*!50001 DROP VIEW IF EXISTS `drinktable`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `drinktable` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `drink_name`,
 1 AS `drink_type`,
 1 AS `drink_price`,
 1 AS `restaurant_rating`,
 1 AS `opening_hrs`,
 1 AS `closing_hrs`,
 1 AS `budget_for_2`,
 1 AS `restaurant_address`,
 1 AS `zipcode`,
 1 AS `city`,
 1 AS `state`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `dishprice`
--

DROP TABLE IF EXISTS `dishprice`;
/*!50001 DROP VIEW IF EXISTS `dishprice`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `dishprice` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `dish_name`,
 1 AS `dish_price`,
 1 AS `restaurant_rating`,
 1 AS `opening_hrs`,
 1 AS `closing_hrs`,
 1 AS `budget_for_2`,
 1 AS `restaurant_address`,
 1 AS `zipcode`,
 1 AS `city`,
 1 AS `state`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `early_juice_resto`
--

DROP TABLE IF EXISTS `early_juice_resto`;
/*!50001 DROP VIEW IF EXISTS `early_juice_resto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `early_juice_resto` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `opening_hrs`,
 1 AS `drink_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `burger_restaurants`
--

DROP TABLE IF EXISTS `burger_restaurants`;
/*!50001 DROP VIEW IF EXISTS `burger_restaurants`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `burger_restaurants` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `dish_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `review_count`
--

DROP TABLE IF EXISTS `review_count`;
/*!50001 DROP VIEW IF EXISTS `review_count`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `review_count` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `COUNT(re.review_comment)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ham_resto`
--

DROP TABLE IF EXISTS `ham_resto`;
/*!50001 DROP VIEW IF EXISTS `ham_resto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `ham_resto` AS SELECT 
 1 AS `restaurant_id`,
 1 AS `restaurant_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `opening_and_closing_hrs`
--

DROP TABLE IF EXISTS `opening_and_closing_hrs`;
/*!50001 DROP VIEW IF EXISTS `opening_and_closing_hrs`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `opening_and_closing_hrs` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `opening_hrs`,
 1 AS `closing_hrs`,
 1 AS `highest_user_rating`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pizza_resto`
--

DROP TABLE IF EXISTS `pizza_resto`;
/*!50001 DROP VIEW IF EXISTS `pizza_resto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pizza_resto` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `dish_name`,
 1 AS `dish_price`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `reservation_details`
--

DROP TABLE IF EXISTS `reservation_details`;
/*!50001 DROP VIEW IF EXISTS `reservation_details`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `reservation_details` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `user_name`,
 1 AS `reservation_date`,
 1 AS `reservation_time`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `userrating`
--

DROP TABLE IF EXISTS `userrating`;
/*!50001 DROP VIEW IF EXISTS `userrating`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `userrating` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `restaurant_rating`,
 1 AS `user_rating`,
 1 AS `opening_hrs`,
 1 AS `closing_hrs`,
 1 AS `budget_for_2`,
 1 AS `restaurant_address`,
 1 AS `zipcode`,
 1 AS `city`,
 1 AS `state`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `alcohol_resto`
--

DROP TABLE IF EXISTS `alcohol_resto`;
/*!50001 DROP VIEW IF EXISTS `alcohol_resto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `alcohol_resto` AS SELECT 
 1 AS `drink_type`,
 1 AS `restaurant_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `early_restaurant`
--

DROP TABLE IF EXISTS `early_restaurant`;
/*!50001 DROP VIEW IF EXISTS `early_restaurant`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `early_restaurant` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `opening_hrs`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `nearby_coffeeshop`
--

DROP TABLE IF EXISTS `nearby_coffeeshop`;
/*!50001 DROP VIEW IF EXISTS `nearby_coffeeshop`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `nearby_coffeeshop` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `drink_name`,
 1 AS `drink_price`,
 1 AS `opening_hrs`,
 1 AS `closing_hrs`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `resto_highest_rating`
--

DROP TABLE IF EXISTS `resto_highest_rating`;
/*!50001 DROP VIEW IF EXISTS `resto_highest_rating`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `resto_highest_rating` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `highest_rating`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `salad_resto`
--

DROP TABLE IF EXISTS `salad_resto`;
/*!50001 DROP VIEW IF EXISTS `salad_resto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `salad_resto` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `dish_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `restype`
--

DROP TABLE IF EXISTS `restype`;
/*!50001 DROP VIEW IF EXISTS `restype`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `restype` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `restaurant_rating`,
 1 AS `opening_hrs`,
 1 AS `closing_hrs`,
 1 AS `budget_for_2`,
 1 AS `restaurant_address`,
 1 AS `zipcode`,
 1 AS `city`,
 1 AS `state`,
 1 AS `restaurant_type`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `kids_menu_resturant`
--

DROP TABLE IF EXISTS `kids_menu_resturant`;
/*!50001 DROP VIEW IF EXISTS `kids_menu_resturant`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `kids_menu_resturant` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `no_of_tables`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `latenight_burger`
--

DROP TABLE IF EXISTS `latenight_burger`;
/*!50001 DROP VIEW IF EXISTS `latenight_burger`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `latenight_burger` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `dish_name`,
 1 AS `closing_hrs`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `drink_price`
--

DROP TABLE IF EXISTS `drink_price`;
/*!50001 DROP VIEW IF EXISTS `drink_price`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `drink_price` AS SELECT 
 1 AS `restaurant_name`,
 1 AS `drink_name`,
 1 AS `drink_price`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `rescategory`
--

/*!50001 DROP VIEW IF EXISTS `rescategory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rescategory` AS select `r`.`restaurant_name` AS `restaurant_name`,`r`.`restaurant_rating` AS `restaurant_rating`,`r`.`opening_hrs` AS `opening_hrs`,`r`.`closing_hrs` AS `closing_hrs`,`r`.`budget_for_2` AS `budget_for_2`,`r`.`restaurant_address` AS `restaurant_address`,`r`.`zipcode` AS `zipcode`,`r`.`city` AS `city`,`r`.`state` AS `state` from (`restaurant` `r` join `restaurant_dishes` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cancellation_details`
--

/*!50001 DROP VIEW IF EXISTS `cancellation_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cancellation_details` AS select `r`.`restaurant_id` AS `restaurant_id`,`r`.`restaurant_name` AS `restaurant_name`,count(`c`.`cancellation_id`) AS `count(c.cancellation_id)` from (`restaurant` `r` join `restaurant_cancellation` `c` on((`r`.`restaurant_id` = `c`.`restaurant_id`))) group by `c`.`restaurant_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `prices_popeyes`
--

/*!50001 DROP VIEW IF EXISTS `prices_popeyes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `prices_popeyes` AS select `dt`.`dish_id` AS `dish_id`,`dt`.`dish_name` AS `dish_name`,`dt`.`dish_price` AS `dish_price` from (`restaurant_dishes` `dt` join `restaurant` `r` on((`dt`.`restaurant_id` = `r`.`restaurant_id`))) where (`r`.`restaurant_name` = 'Popeyes') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fast_food_resto`
--

/*!50001 DROP VIEW IF EXISTS `fast_food_resto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `fast_food_resto` AS select `r`.`restaurant_name` AS `restaurant_name`,`rt`.`restaurant_type` AS `restaurant_type` from ((`restaurant` `r` join `restaurant_type_mapping` `rtm`) join `restaurant_type` `rt` on((`r`.`restaurant_id` = `rtm`.`restaurant_id`))) where (`rt`.`restaurant_type` = 'Fast food restaurant') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `coffee_and_fries`
--

/*!50001 DROP VIEW IF EXISTS `coffee_and_fries`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `coffee_and_fries` AS select distinct `r`.`restaurant_id` AS `restaurant_id`,`r`.`restaurant_name` AS `restaurant_name`,`r`.`restaurant_rating` AS `restaurant_rating` from ((`restaurant` `r` join `drinks` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) join `restaurant_dishes` `rd` on((`r`.`restaurant_id` = `rd`.`restaurant_id`))) where ((`d`.`drink_name` like '%Coffee%') and (`rd`.`dish_name` like '%Fries%')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `drinktable`
--

/*!50001 DROP VIEW IF EXISTS `drinktable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `drinktable` AS select `r`.`restaurant_name` AS `restaurant_name`,`d`.`drink_name` AS `drink_name`,`d`.`drink_type` AS `drink_type`,`d`.`drink_price` AS `drink_price`,`r`.`restaurant_rating` AS `restaurant_rating`,`r`.`opening_hrs` AS `opening_hrs`,`r`.`closing_hrs` AS `closing_hrs`,`r`.`budget_for_2` AS `budget_for_2`,`r`.`restaurant_address` AS `restaurant_address`,`r`.`zipcode` AS `zipcode`,`r`.`city` AS `city`,`r`.`state` AS `state` from (`restaurant` `r` join `drinks` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `dishprice`
--

/*!50001 DROP VIEW IF EXISTS `dishprice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `dishprice` AS select `r`.`restaurant_name` AS `restaurant_name`,`d`.`dish_name` AS `dish_name`,`d`.`dish_price` AS `dish_price`,`r`.`restaurant_rating` AS `restaurant_rating`,`r`.`opening_hrs` AS `opening_hrs`,`r`.`closing_hrs` AS `closing_hrs`,`r`.`budget_for_2` AS `budget_for_2`,`r`.`restaurant_address` AS `restaurant_address`,`r`.`zipcode` AS `zipcode`,`r`.`city` AS `city`,`r`.`state` AS `state` from (`restaurant` `r` join `restaurant_dishes` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `early_juice_resto`
--

/*!50001 DROP VIEW IF EXISTS `early_juice_resto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `early_juice_resto` AS select `r`.`restaurant_name` AS `restaurant_name`,`r`.`opening_hrs` AS `opening_hrs`,`d`.`drink_name` AS `drink_name` from (`restaurant` `r` join `drinks` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) where ((`r`.`opening_hrs` = '11:00:00') and (`d`.`drink_name` = 'Organic Apple Juice Regular (6.75 oz.) ')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `burger_restaurants`
--

/*!50001 DROP VIEW IF EXISTS `burger_restaurants`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `burger_restaurants` AS select distinct `r`.`restaurant_name` AS `restaurant_name`,`d`.`dish_name` AS `dish_name` from (`restaurant` `r` join `restaurant_dishes` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) where ((`r`.`zipcode` = '2115') and `d`.`category_id` in (select `dish_categories`.`category_id` from `dish_categories` where (`dish_categories`.`category_name` like '%Burger%'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `review_count`
--

/*!50001 DROP VIEW IF EXISTS `review_count`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `review_count` AS select `r`.`restaurant_name` AS `restaurant_name`,count(`re`.`review_comment`) AS `COUNT(re.review_comment)` from (`restaurant_review` `re` join `restaurant` `r` on((`r`.`restaurant_id` = `re`.`restaurant_id`))) group by `r`.`restaurant_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ham_resto`
--

/*!50001 DROP VIEW IF EXISTS `ham_resto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ham_resto` AS select `r`.`restaurant_id` AS `restaurant_id`,`r`.`restaurant_name` AS `restaurant_name` from (`restaurant` `r` join `restaurant_dishes` `rd` on((`r`.`restaurant_id` = `rd`.`restaurant_id`))) where (`rd`.`dish_name` = 'Hamburger ') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `opening_and_closing_hrs`
--

/*!50001 DROP VIEW IF EXISTS `opening_and_closing_hrs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `opening_and_closing_hrs` AS select `r`.`restaurant_name` AS `restaurant_name`,`r`.`opening_hrs` AS `opening_hrs`,`r`.`closing_hrs` AS `closing_hrs`,max(`rv`.`user_rating`) AS `highest_user_rating` from (`restaurant` `r` join `restaurant_review` `rv` on((`r`.`restaurant_id` = `rv`.`restaurant_id`))) where (`rv`.`user_rating` > 4) group by `r`.`restaurant_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pizza_resto`
--

/*!50001 DROP VIEW IF EXISTS `pizza_resto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `pizza_resto` AS select distinct `r`.`restaurant_name` AS `restaurant_name`,`d`.`dish_name` AS `dish_name`,`d`.`dish_price` AS `dish_price` from (`restaurant` `r` join `restaurant_dishes` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) where (`d`.`category_id` in (select `dish_categories`.`category_id` from `dish_categories` where (`dish_categories`.`category_name` like '%Pizza%')) and (`r`.`budget_for_2` <= 20)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `reservation_details`
--

/*!50001 DROP VIEW IF EXISTS `reservation_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `reservation_details` AS select `r`.`restaurant_name` AS `restaurant_name`,concat(`u`.`user_first_name`,' ',`u`.`user_last_name`) AS `user_name`,`rs`.`reservation_date` AS `reservation_date`,`rs`.`reservation_time` AS `reservation_time` from ((`restaurant` `r` join `restaurant_reservation` `rs` on((`r`.`restaurant_id` = `rs`.`restaurant_id`))) join `user` `u` on((`rs`.`user_id` = `u`.`user_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `userrating`
--

/*!50001 DROP VIEW IF EXISTS `userrating`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `userrating` AS select `r`.`restaurant_name` AS `restaurant_name`,`r`.`restaurant_rating` AS `restaurant_rating`,max(`re`.`user_rating`) AS `user_rating`,`r`.`opening_hrs` AS `opening_hrs`,`r`.`closing_hrs` AS `closing_hrs`,`r`.`budget_for_2` AS `budget_for_2`,`r`.`restaurant_address` AS `restaurant_address`,`r`.`zipcode` AS `zipcode`,`r`.`city` AS `city`,`r`.`state` AS `state` from (`restaurant` `r` join `restaurant_review` `re` on((`r`.`restaurant_id` = `re`.`restaurant_id`))) group by `r`.`restaurant_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `alcohol_resto`
--

/*!50001 DROP VIEW IF EXISTS `alcohol_resto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `alcohol_resto` AS select distinct `d`.`drink_type` AS `drink_type`,`r`.`restaurant_name` AS `restaurant_name` from (`restaurant` `r` join `drinks` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) where (`d`.`drink_type` in ('Beer','Wine')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `early_restaurant`
--

/*!50001 DROP VIEW IF EXISTS `early_restaurant`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `early_restaurant` AS select distinct `r`.`restaurant_name` AS `restaurant_name`,`r`.`opening_hrs` AS `opening_hrs` from (`restaurant` `r` join `restaurant_review` `re` on((`r`.`restaurant_id` = `re`.`restaurant_id`))) where ((`r`.`opening_hrs` = '08:00:00') and (`re`.`user_rating` >= 4)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `nearby_coffeeshop`
--

/*!50001 DROP VIEW IF EXISTS `nearby_coffeeshop`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `nearby_coffeeshop` AS select `r`.`restaurant_name` AS `restaurant_name`,`d`.`drink_name` AS `drink_name`,`d`.`drink_price` AS `drink_price`,`r`.`opening_hrs` AS `opening_hrs`,`r`.`closing_hrs` AS `closing_hrs` from (`restaurant` `r` join `drinks` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) where ((`d`.`drink_name` like '%Coffee%') and (`r`.`zipcode` = '2115')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `resto_highest_rating`
--

/*!50001 DROP VIEW IF EXISTS `resto_highest_rating`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `resto_highest_rating` AS select `r`.`restaurant_name` AS `restaurant_name`,max(`re`.`user_rating`) AS `highest_rating` from (`restaurant` `r` join `restaurant_review` `re` on((`r`.`restaurant_id` = `re`.`restaurant_id`))) group by `r`.`restaurant_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `salad_resto`
--

/*!50001 DROP VIEW IF EXISTS `salad_resto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `salad_resto` AS select distinct `r`.`restaurant_name` AS `restaurant_name`,`d`.`dish_name` AS `dish_name` from (`restaurant` `r` join `restaurant_dishes` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) where `d`.`category_id` in (select `dish_categories`.`category_id` from `dish_categories` where (`dish_categories`.`category_name` like '%Salad%')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `restype`
--

/*!50001 DROP VIEW IF EXISTS `restype`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `restype` AS select distinct `r`.`restaurant_name` AS `restaurant_name`,`r`.`restaurant_rating` AS `restaurant_rating`,`r`.`opening_hrs` AS `opening_hrs`,`r`.`closing_hrs` AS `closing_hrs`,`r`.`budget_for_2` AS `budget_for_2`,`r`.`restaurant_address` AS `restaurant_address`,`r`.`zipcode` AS `zipcode`,`r`.`city` AS `city`,`r`.`state` AS `state`,`t`.`restaurant_type` AS `restaurant_type` from ((`restaurant` `r` join `restaurant_type_mapping` `tm` on((`r`.`restaurant_id` = `tm`.`restaurant_id`))) join `restaurant_type` `t` on((`t`.`restaurant_type_id` = `tm`.`restaurant_type_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `kids_menu_resturant`
--

/*!50001 DROP VIEW IF EXISTS `kids_menu_resturant`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `kids_menu_resturant` AS select distinct `r`.`restaurant_name` AS `restaurant_name`,`r`.`no_of_tables` AS `no_of_tables` from (`restaurant` `r` join `restaurant_dishes` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) where `d`.`category_id` in (select `dish_categories`.`category_id` from `dish_categories` where (`dish_categories`.`category_name` like '%kid%')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latenight_burger`
--

/*!50001 DROP VIEW IF EXISTS `latenight_burger`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `latenight_burger` AS select `r`.`restaurant_name` AS `restaurant_name`,`rd`.`dish_name` AS `dish_name`,`r`.`closing_hrs` AS `closing_hrs` from (`restaurant_dishes` `rd` join `restaurant` `r` on((`rd`.`restaurant_id` = `r`.`restaurant_id`))) where ((`rd`.`dish_name` like '%Cheeseburger%') and (`r`.`closing_hrs` <= '22:00:00')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `drink_price`
--

/*!50001 DROP VIEW IF EXISTS `drink_price`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `drink_price` AS select `r`.`restaurant_name` AS `restaurant_name`,`d`.`drink_name` AS `drink_name`,`d`.`drink_price` AS `drink_price` from (`restaurant` `r` join `drinks` `d` on((`r`.`restaurant_id` = `d`.`restaurant_id`))) where (`d`.`drink_price` < 3) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-14 20:41:16
